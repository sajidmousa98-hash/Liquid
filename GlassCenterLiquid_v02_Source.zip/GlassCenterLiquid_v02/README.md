# Glass Center Liquid Test v0.2 — source project (NOT prebuilt APK)

Phone-first Android 12+ Java/Gradle project, targeted at Galaxy S23, One UI 9 / Android 17; does **not** change `com.android.systemui`. No root requirement, and NO root commands are performed.

## Implemented in source
- Android-native cross-window background blur behind the overlay via `FLAG_BLUR_BEHIND` and `setBlurBehindRadius`. **This is real live blur** when enabled by the OS/GPU; some devices or power modes disable it. It blurs behind the entire panel window, not separately per tile.
- GPU-accelerated AGSL runtime shader on Android 13+ for animated glass color/lighting, chromatic edges, wavy highlights, touches/ripples, and shader fallback for Android 12.
- Translucent rounded controls; responsive press-scale and opening/closing overshoot animation.
- Touch sliders for brightness and media volume, flashlight via camera, Wi-Fi/Bluetooth/cellular/airplane/DND settings shortcuts, and media sessions (play/pause, next, previous) when notification access is granted.
- A small floating opening handle below the status bar, visible stop action, foreground service.

## NOT implemented or verified
- **Real-time refraction of pixels from apps behind each glass tile** — AGSL here distorts a *procedural texture*, not pixels from the underlying app. Implementing actual cross-app refraction requires permitted capture (MediaProjection with user prompt every session, and difficult overlay feedback avoidance), or a more deeply integrated compositor/OEM path. Do not mistake the wobble/glint effect for true background-pixel distortion.
- Apple's proprietary iOS 27 renderer / pixel-identical visuals, authentic full SystemUI replacement, instantaneous privileged Wi-Fi/mobile data toggles, all Apple Control Center modules, configurable tile layout, or LSPosed/KernelSU integration.
- This source has not been compiled or tested on the physical Galaxy S23. This environment lacks Android SDK/Gradle. Compile errors and runtime compatibility issues may still exist.

## Build exclusively on phone
1. Install **Code on the Go** from https://appdevforall.org/code-on-the-go/ . It offers Android app compilation on the device. Alternatives may work too.
2. Extract this zip, import the `GlassCenterLiquid_v02` directory as a Gradle project. It uses Java 17, Android Gradle Plugin 8.7.3, compileSdk 35, minSdk 31, targetSdk 35. Configure matching SDK/Gradle plugins in the mobile IDE and let it sync. No Gradle wrapper binary is bundled.
3. Build the `app` debug variant. Install the generated `app-debug.apk`.
4. Open **Glass Center Liquid Test**, grant **Display over other apps**, **Modify system settings** and optionally **Notification access** for media controls.
5. Tap START. Tap the small arrow below the top-right status bar. Drag the brightness/volume sliders; test opening the Wi-Fi/Bluetooth panels, flashlight and media buttons. Stop from the app or foreground notification.
6. If build/import fails, copy the error output or a screenshot back to the conversation to correct it.

## Samsung-specific caveats
- OEM Android settings may block cross-window blur in battery-saving modes; effects then show fallback gradient but no system background blur.
- The app uses an **overlay**; the stock One UI quick panel continues to work. No status-bar interception or APK patching.
- Screen captures, financial/banking apps and protected surfaces are **not** read by this app.
- Automatic brightness may change manual brightness setting again. Camera or flashlight can be unavailable while camera is in use.
- Pressing the small handle may conflict with certain app gestures. The handle can be turned off by stopping the overlay.

## Technical architecture
- `MainActivity.java` — onboarding & permissions.
- `OverlayService.java` — foreground service, overlay window, native compositor blur, layout, music and device control actions, timed redraw only while open.
- `LiquidGlassDrawable.java` — shader material (AGSL), specular, edges and ripples. No sampling of third-party screen content.
- `GlassSlider.java` — animated vertical slider controls.
- `MediaListener.java` — explicit user-enabled media notification access.

## Safety
The SystemUI.apk you shared is NOT modified by the project. Never flash or overwrite Samsung SystemUI with an unsigned replacement. Have recovery/backup options before future KernelSU/LSPosed work.
