package dev.local.glasscenter;

import android.service.notification.NotificationListenerService;

/** User-enabled notification access lets the app read active media sessions. */
public final class MediaListener extends NotificationListenerService { }
