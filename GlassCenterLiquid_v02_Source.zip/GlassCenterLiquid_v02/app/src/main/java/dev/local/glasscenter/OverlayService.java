package dev.local.glasscenter;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Reversible Android 12+ overlay, no root operations and no modifications to Samsung SystemUI.
 * Background blur is real and performed by the OS compositor when supported and enabled.
 * Tile material / optical highlights are procedural, not sampled from other applications.
 */
public final class OverlayService extends Service {
    public static final String ACTION_STOP = "dev.local.glasscenter.action.STOP";
    public static final String ACTION_OPEN = "dev.local.glasscenter.action.OPEN";
    private static final String CHANNEL = "glass_liquid_overlay";
    private static final int NOTIFICATION_ID = 2037;
    private WindowManager wm;
    private View handle;
    private FrameLayout panel;
    private LinearLayout sheet;
    private CameraManager camera;
    private String torchId;
    private boolean torchOn;
    private float startY;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<LiquidGlassDrawable> materials = new ArrayList<>();
    private long openedTime;
    private TextView mediaTitle;
    private TextView mediaSubtitle;
    private MediaController currentController;
    private boolean blurAvailable=true;
    private final Runnable frameTick = new Runnable() {
        @Override public void run() {
            if(panel==null)return;
            float t=(android.os.SystemClock.uptimeMillis()-openedTime)/1000f;
            for(LiquidGlassDrawable d:materials)d.update(t);
            handler.postDelayed(this,33L); // ~30fps, only while visible; low overhead fallback
        }
    };
    private final Runnable mediaTick = new Runnable(){
        @Override public void run(){if(panel==null)return;updateMedia();handler.postDelayed(this,2200);}
    };

    private int dp(float v){return (int)(getResources().getDisplayMetrics().density*v+.5f);}
    @Override public IBinder onBind(Intent i){return null;}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null && ACTION_STOP.equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
        if(!Settings.canDrawOverlays(this)){
            Toast.makeText(this,"Grant overlay access from Glass Center settings",Toast.LENGTH_LONG).show();
            stopSelf();return START_NOT_STICKY;
        }
        startNotification();
        if(wm==null)wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        if(handle==null)try{showHandle();}catch(Exception e){Toast.makeText(this,"Overlay failed: "+e.getMessage(),Toast.LENGTH_LONG).show();stopSelf();}
        if(intent!=null && ACTION_OPEN.equals(intent.getAction()))showPanel();
        return START_NOT_STICKY;
    }

    private void startNotification(){
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Glass Center",NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop=PendingIntent.getService(this,2,
                new Intent(this,OverlayService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent open=PendingIntent.getService(this,3,
                new Intent(this,OverlayService.class).setAction(ACTION_OPEN),
                PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(this,CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_manage)
                .setContentTitle("Liquid Control Center active")
                .setContentText("Tap to open · Stop from notification")
                .setContentIntent(open).setOngoing(true)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"Stop",stop).build())
                .build();
        startForeground(NOTIFICATION_ID,n);
    }

    private WindowManager.LayoutParams params(int w,int h,int gravity){
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(w,h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT);
        p.gravity=gravity;p.setTitle("Liquid Glass Center");return p;
    }
    private int statusBarHeight(){int id=getResources().getIdentifier("status_bar_height","dimen","android");return id>0?getResources().getDimensionPixelSize(id):dp(30);}
    private GradientDrawable bg(int fill,int radius,int stroke){
        GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radius));
        if(stroke!=0)d.setStroke(dp(1),stroke);return d;
    }
    private TextView text(String s,int size,int color){
        TextView v=new TextView(this);v.setText(s);v.setTextColor(color);v.setTextSize(size);
        v.setGravity(Gravity.CENTER_VERTICAL);return v;
    }
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private void showHandle(){
        TextView pill=text("⌄",24,Color.WHITE);pill.setGravity(Gravity.CENTER);
        pill.setBackground(bg(0xc7435c78,18,0x88ffffff));
        pill.setContentDescription("Open Liquid Control Center");
        pill.setOnTouchListener((v,e)->{
            if(e.getActionMasked()==MotionEvent.ACTION_DOWN){startY=e.getRawY();return true;}
            if(e.getActionMasked()==MotionEvent.ACTION_UP){showPanel();return true;}
            return true;
        });
        WindowManager.LayoutParams p=params(dp(65),dp(26),Gravity.TOP|Gravity.END);
        p.x=dp(14);p.y=statusBarHeight()+dp(7);
        wm.addView(pill,p);handle=pill;
    }
    private void openSettings(Intent i){
        try{i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);hidePanel();}
        catch(Exception e){Toast.makeText(this,"Cannot open system settings",Toast.LENGTH_SHORT).show();}
    }
    private void addTileRow(LinearLayout parent,View a,View b){
        LinearLayout r=row();LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(12);
        parent.addView(r,rp);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(106),1);
        lp.rightMargin=dp(6);r.addView(a,lp);
        LinearLayout.LayoutParams rp2=new LinearLayout.LayoutParams(0,dp(106),1);
        rp2.leftMargin=dp(6);r.addView(b,rp2);
    }
    private View tile(String icon,String title,String detail,View.OnClickListener click){
        FrameLayout glass=new FrameLayout(this);
        LiquidGlassDrawable material=new LiquidGlassDrawable(dp(27));glass.setBackground(material);materials.add(material);
        LinearLayout content=col();content.setGravity(Gravity.CENTER_VERTICAL);
        content.setPadding(dp(15),dp(13),dp(10),dp(12));
        TextView glyph=text(icon,27,Color.WHITE);content.addView(glyph,new LinearLayout.LayoutParams(-1,dp(37)));
        TextView name=text(title,15,Color.WHITE);name.setSingleLine(true);content.addView(name);
        TextView sub=text(detail,11,0xffe1ebf5);sub.setSingleLine(true);content.addView(sub);
        glass.addView(content,new FrameLayout.LayoutParams(-1,-1));
        glass.setClickable(true);
        glass.setOnClickListener(click);
        glass.setOnTouchListener((v,e)->{
            if(e.getActionMasked()==MotionEvent.ACTION_DOWN){
                material.press(e.getX()/Math.max(1,v.getWidth()),e.getY()/Math.max(1,v.getHeight()),true);
                v.animate().scaleX(.95f).scaleY(.95f).setDuration(100).start();
            }else if(e.getActionMasked()==MotionEvent.ACTION_UP||e.getActionMasked()==MotionEvent.ACTION_CANCEL){
                material.press(.5f,.5f,false);
                v.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(new OvershootInterpolator(1.6f)).start();
            }
            return false;
        });
        return glass;
    }
    private void sectionLabel(LinearLayout parent,String label){
        TextView heading=text(label,17,0xffe9f2fc);
        heading.setPadding(dp(4),dp(20),0,dp(6));
        parent.addView(heading);
    }
    private void toggleTorch(){
        try{
            if(camera==null)camera=(CameraManager)getSystemService(CAMERA_SERVICE);
            if(torchId==null){
                for(String id:camera.getCameraIdList()){
                    CameraCharacteristics c=camera.getCameraCharacteristics(id);
                    if(Boolean.TRUE.equals(c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE)) &&
                            Integer.valueOf(CameraCharacteristics.LENS_FACING_BACK).equals(c.get(CameraCharacteristics.LENS_FACING))){
                        torchId=id;break;
                    }
                }
            }
            if(torchId==null){Toast.makeText(this,"Back flashlight unavailable",Toast.LENGTH_SHORT).show();return;}
            camera.setTorchMode(torchId,!torchOn);torchOn=!torchOn;
        }catch(Exception e){Toast.makeText(this,"Flashlight unavailable",Toast.LENGTH_SHORT).show();}
    }
    private void brightness(float fraction){
        if(!Settings.System.canWrite(this)){
            Toast.makeText(this,"Allow Modify system settings",Toast.LENGTH_SHORT).show();return;
        }
        try{
            // The system's auto-brightness may adjust this value after the gesture.
            Settings.System.putInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS,
                Math.max(1,Math.min(255,Math.round(fraction*255f))));
        }catch(Exception ignored){}
    }
    private void playPause(){
        updateMedia();
        if(currentController==null){openSettings(new Intent(Settings.ACTION_SOUND_SETTINGS));return;}
        try{
            android.media.session.PlaybackState state=currentController.getPlaybackState();
            if(state!=null && state.getState()==android.media.session.PlaybackState.STATE_PLAYING)
                currentController.getTransportControls().pause();
            else currentController.getTransportControls().play();
        }catch(Exception e){Toast.makeText(this,"Playback control not available",Toast.LENGTH_SHORT).show();}
    }
    private void skip(){
        if(currentController!=null)try{currentController.getTransportControls().skipToNext();}catch(Exception ignored){}
    }
    private void updateMedia(){
        if(mediaTitle==null)return;
        String title="Nothing playing",sub="Grant notification access for media";
        currentController=null;
        try{
            MediaSessionManager manager=(MediaSessionManager)getSystemService(Context.MEDIA_SESSION_SERVICE);
            ComponentName listener=new ComponentName(this,MediaListener.class);
            List<MediaController> sessions=manager.getActiveSessions(listener);
            if(!sessions.isEmpty()){
                MediaController best=sessions.get(0);
                for(MediaController candidate:sessions){
                    android.media.session.PlaybackState ps=candidate.getPlaybackState();
                    if(ps!=null && ps.getState()==android.media.session.PlaybackState.STATE_PLAYING){best=candidate;break;}
                }
                currentController=best;
                MediaMetadata m=best.getMetadata();
                if(m!=null){
                    String t=m.getString(MediaMetadata.METADATA_KEY_TITLE);
                    String a=m.getString(MediaMetadata.METADATA_KEY_ARTIST);
                    if(t!=null&&!t.isEmpty())title=t;
                    if(a!=null&&!a.isEmpty())sub=a;
                }
            }
        }catch(SecurityException ignored){}catch(Exception ignored){}
        mediaTitle.setText(title);mediaSubtitle.setText(sub);
    }
    private View mediaCard(){
        FrameLayout card=new FrameLayout(this);LiquidGlassDrawable d=new LiquidGlassDrawable(dp(28));
        card.setBackground(d);materials.add(d);
        LinearLayout inside=col();inside.setPadding(dp(16),dp(12),dp(16),dp(14));
        mediaTitle=text("Nothing playing",17,Color.WHITE);mediaTitle.setSingleLine(true);
        mediaSubtitle=text("Grant notification access for media",12,0xffd3e7ff);mediaSubtitle.setSingleLine(true);
        inside.addView(mediaTitle);inside.addView(mediaSubtitle);
        LinearLayout controls=row();controls.setGravity(Gravity.CENTER);
        TextView back=text("◀◀",22,Color.WHITE);back.setPadding(dp(20),dp(8),dp(20),dp(8));
        back.setOnClickListener(v->{if(currentController!=null)try{currentController.getTransportControls().skipToPrevious();}catch(Exception ignored){}});
        TextView play=text("▶  /  Ⅱ",22,Color.WHITE);play.setPadding(dp(15),dp(8),dp(15),dp(8));play.setOnClickListener(v->playPause());
        TextView next=text("▶▶",22,Color.WHITE);next.setPadding(dp(20),dp(8),dp(20),dp(8));next.setOnClickListener(v->skip());
        controls.addView(back);controls.addView(play);controls.addView(next);
        LinearLayout.LayoutParams buttonLp=new LinearLayout.LayoutParams(-1,-2);buttonLp.topMargin=dp(10);
        inside.addView(controls,buttonLp);card.addView(inside);
        return card;
    }

    private void showPanel(){
        if(panel!=null || wm==null)return;
        materials.clear();mediaTitle=null;mediaSubtitle=null;
        FrameLayout root=new FrameLayout(this);
        root.setBackgroundColor(0x42081120); // semi transparent: compositor blur behind remains visible
        root.setOnClickListener(v->hidePanel());
        ScrollView scroll=new ScrollView(this);scroll.setVerticalScrollBarEnabled(false);scroll.setFillViewport(true);
        root.addView(scroll,new FrameLayout.LayoutParams(-1,-1));
        sheet=col();sheet.setPadding(dp(18),statusBarHeight()+dp(14),dp(18),dp(40));
        sheet.setOnClickListener(v->{});
        scroll.addView(sheet);
        LinearLayout top=row();TextView title=text("Control Center",26,Color.WHITE);
        top.addView(title,new LinearLayout.LayoutParams(0,dp(42),1));
        TextView close=text("✕",22,Color.WHITE);close.setPadding(dp(18),0,dp(8),0);close.setOnClickListener(v->hidePanel());
        top.addView(close);sheet.addView(top);
        TextView date=text(new SimpleDateFormat("EEEE, d MMM · HH:mm",Locale.getDefault()).format(new Date()),12,0xffd8e4f6);
        date.setPadding(dp(4),0,0,dp(4));sheet.addView(date);
        sectionLabel(sheet,"Connectivity");
        addTileRow(sheet,
            tile("◉","Wi-Fi","Internet settings",v->openSettings(new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))),
            tile("ᛒ","Bluetooth","Device settings",v->openSettings(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS))));
        addTileRow(sheet,
            tile("✈","Airplane Mode","System controls",v->openSettings(new Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))),
            tile("▤","Mobile Data","Network settings",v->openSettings(new Intent(Settings.ACTION_DATA_ROAMING_SETTINGS))));
        sectionLabel(sheet,"Now Playing");
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,-2);mp.topMargin=dp(8);
        sheet.addView(mediaCard(),mp);
        sectionLabel(sheet,"Brightness & Volume");
        LinearLayout sliders=row();sliders.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sliderSection=new LinearLayout.LayoutParams(-1,dp(181));sliderSection.topMargin=dp(9);
        sheet.addView(sliders,sliderSection);
        float startBrightness=.5f;
        try{startBrightness=Settings.System.getInt(getContentResolver(),Settings.System.SCREEN_BRIGHTNESS)/255f;}catch(Exception ignored){}
        GlassSlider bright=new GlassSlider(this,"☀",startBrightness);
        bright.setContentDescription("Brightness slider");bright.setOnLevelChanged(this::brightness);
        LinearLayout.LayoutParams a=new LinearLayout.LayoutParams(0,-1,1);a.rightMargin=dp(8);sliders.addView(bright,a);
        AudioManager audio=(AudioManager)getSystemService(Context.AUDIO_SERVICE);
        int max=Math.max(1,audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        GlassSlider volume=new GlassSlider(this,"♫",audio.getStreamVolume(AudioManager.STREAM_MUSIC)/(float)max);
        volume.setContentDescription("Media volume slider");
        volume.setOnLevelChanged(value->audio.setStreamVolume(AudioManager.STREAM_MUSIC,Math.round(value*max),0));
        LinearLayout.LayoutParams b=new LinearLayout.LayoutParams(0,-1,1);b.leftMargin=dp(8);sliders.addView(volume,b);
        sectionLabel(sheet,"Quick Access");
        addTileRow(sheet,
            tile("✦","Flashlight","Tap to toggle",v->toggleTorch()),
            tile("◐","Display","Screen settings",v->openSettings(new Intent(Settings.ACTION_DISPLAY_SETTINGS))));
        addTileRow(sheet,
            tile("☾","Focus","Do Not Disturb",v->openSettings(new Intent(Settings.ACTION_ZEN_MODE_SETTINGS))),
            tile("⚙","Settings","Android settings",v->openSettings(new Intent(Settings.ACTION_SETTINGS))));
        TextView foot=text("LIQUID TEST · Native compositor blur + GPU animated glass. True cross-app pixel refraction is not included. Original Samsung Quick Panel remains available.",11,0xffc6d9ef);
        foot.setPadding(dp(7),dp(23),dp(7),dp(4));sheet.addView(foot);

        WindowManager.LayoutParams p=params(-1,-1,Gravity.TOP|Gravity.START);
        p.flags|=WindowManager.LayoutParams.FLAG_BLUR_BEHIND|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        p.setBlurBehindRadius(dp(45));
        try{
            wm.addView(root,p);panel=root;
            openedTime=android.os.SystemClock.uptimeMillis();
            sheet.setTranslationY(-dp(42));sheet.setAlpha(0f);sheet.setScaleX(.97f);sheet.setScaleY(.97f);
            sheet.animate().translationY(0).alpha(1).scaleX(1).scaleY(1)
                .setDuration(410).setInterpolator(new OvershootInterpolator(.84f)).start();
            handler.post(frameTick);handler.post(mediaTick);
        }catch(Exception e){
            panel=null;materials.clear();mediaTitle=null;mediaSubtitle=null;
            Toast.makeText(this,"Could not open overlay: "+e.getClass().getSimpleName(),Toast.LENGTH_SHORT).show();
        }
    }

    private void hidePanel(){
        if(panel==null)return;
        final FrameLayout going=panel;
        panel=null;
        handler.removeCallbacks(frameTick);handler.removeCallbacks(mediaTick);
        materials.clear();mediaTitle=null;mediaSubtitle=null;currentController=null;
        if(sheet!=null){
            sheet.animate().alpha(0).translationY(-dp(20)).scaleX(.98f).scaleY(.98f)
                .setDuration(170).setInterpolator(new DecelerateInterpolator()).withEndAction(()->{
                    try{wm.removeView(going);}catch(Exception ignored){}
                }).start();
        }else{
            try{wm.removeView(going);}catch(Exception ignored){}
        }
    }
    @Override public void onDestroy(){
        handler.removeCallbacks(frameTick);handler.removeCallbacks(mediaTick);
        if(panel!=null){try{wm.removeViewImmediate(panel);}catch(Exception ignored){}panel=null;}
        if(handle!=null){try{wm.removeViewImmediate(handle);}catch(Exception ignored){}handle=null;}
        if(torchOn&&camera!=null&&torchId!=null)try{camera.setTorchMode(torchId,false);}catch(Exception ignored){}
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }
}
