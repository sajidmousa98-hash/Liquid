package dev.local.glasscenter;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.RuntimeShader;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.os.Build;

/**
 * Procedural glass material. Native cross-window compositor blur is set by OverlayService.
 * This shader draws refraction-like moving gradients, chromatic edges, and specular glints;
 * it does NOT sample pixels from other apps. This distinction is intentional.
 */
public final class LiquidGlassDrawable extends Drawable {
    private static final String AGSL =
        "uniform float2 size;\n" +
        "uniform float time;\n" +
        "uniform float2 touch;\n" +
        "uniform float down;\n" +
        "half4 main(float2 xy) {\n" +
        " float2 uv = xy / max(size,float2(1.0,1.0));\n" +
        " float2 p = uv-float2(.5,.5);\n" +
        " float ripple = sin(length(uv-touch)*35.0-time*5.0)*exp(-length(uv-touch)*8.0)*down;\n" +
        " float wave = sin(uv.x*8.0+time*.55+sin(uv.y*6.0+time*.3))*.5+.5;\n" +
        " float bend = .011*sin(uv.y*9.0+time*.7)+.008*ripple;\n" +
        " float2 distorted = uv+float2(bend,sin(uv.x*10.0+time*.8)*.008);\n" +
        " float fresnel = pow(clamp(1.0-2.0*min(min(uv.x,1.0-uv.x),min(uv.y,1.0-uv.y)),0.0,1.0),7.0);\n" +
        " float beam = pow(max(0.0,1.0-abs(distorted.x-(.20+.42*sin(time*.22+distorted.y*1.8)))),14.0);\n" +
        " float top = pow(1.0-smoothstep(0.0,.13,uv.y),3.0);\n" +
        " float shimmer = (wave*.09+beam*.20+top*.20+fresnel*.19+ripple*.045);\n" +
        " float3 rgb = float3(.50,.67,.86)+float3(shimmer,shimmer*.91,shimmer*.96);\n" +
        " rgb.r+=fresnel*.09; rgb.b+=fresnel*.035;\n" +
        " float alpha = clamp(.16+shimmer*.48+fresnel*.12,.11,.50);\n" +
        " return half4(half3(rgb),half(alpha));\n" +
        "}\n";

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint faint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private RuntimeShader shader;
    private float time;
    private float touchX=.5f,touchY=.5f,down;
    private final float radius;
    private int alpha=255;

    public LiquidGlassDrawable(float radiusPx) {
        radius=radiusPx;
        if(Build.VERSION.SDK_INT>=33) {
            try { shader = new RuntimeShader(AGSL); fill.setShader(shader); }
            catch(Exception ignored) { shader=null; }
        }
        edge.setStyle(Paint.Style.STROKE);
        edge.setStrokeWidth(1.3f);
        faint.setStyle(Paint.Style.STROKE);
        faint.setStrokeWidth(0.7f);
    }

    public void update(float seconds) { time=seconds; invalidateSelf(); }
    public void press(float x, float y, boolean pressed) {
        touchX=x; touchY=y; down=pressed?1f:0f; invalidateSelf();
    }
    @Override public void draw(Canvas canvas) {
        Rect b=getBounds(); float w=b.width(),h=b.height();
        if(w<=0 || h<=0)return;
        RectF rect=new RectF(b.left,b.top,b.right,b.bottom);
        if(shader!=null) {
            shader.setFloatUniform("size",w,h);
            shader.setFloatUniform("time",time);
            shader.setFloatUniform("touch",touchX,touchY);
            shader.setFloatUniform("down",down);
            fill.setAlpha(alpha);
        } else {
            fill.setShader(new LinearGradient(b.left,b.top,b.right,b.bottom,
                    0x65b2d8f5,0x294f7199,Shader.TileMode.CLAMP));
            fill.setAlpha(alpha);
        }
        canvas.drawRoundRect(rect,radius,radius,fill);
        edge.setColor(0xaaffffff); edge.setAlpha(alpha*170/255);
        canvas.drawRoundRect(new RectF(rect.left+1,rect.top+1,rect.right-1,rect.bottom-1),
                Math.max(0,radius-1),Math.max(0,radius-1),edge);
        faint.setColor(0xffa5d4fa); faint.setAlpha(alpha*90/255);
        canvas.drawRoundRect(new RectF(rect.left+2.5f,rect.top+2.5f,rect.right-2.5f,rect.bottom-2.5f),
                Math.max(0,radius-2),Math.max(0,radius-2),faint);
    }
    @Override public void setAlpha(int value) { alpha=value; invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter filter) { fill.setColorFilter(filter); }
    @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
