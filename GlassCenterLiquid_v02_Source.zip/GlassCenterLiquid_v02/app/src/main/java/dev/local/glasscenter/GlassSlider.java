package dev.local.glasscenter;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/** Vertical liquid slider. Provides normalized 0..1 events. */
public final class GlassSlider extends View {
    public interface OnLevelChanged { void onChanged(float value); }
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private float level;
    private final String symbol;
    private OnLevelChanged listener;
    private boolean dragging;
    private int dp(float v){return (int)(getResources().getDisplayMetrics().density*v+.5f);}
    public GlassSlider(Context context,String icon,float initial){super(context);symbol=icon;level=initial;setLayerType(View.LAYER_TYPE_HARDWARE,null);}
    public void setOnLevelChanged(OnLevelChanged l){listener=l;}
    public void setLevel(float l){level=Math.max(0,Math.min(1,l));invalidate();}
    @Override protected void onMeasure(int w,int h){setMeasuredDimension(MeasureSpec.getSize(w),dp(173));}
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);float w=getWidth(),h=getHeight(),r=dp(27);
        paint.setStyle(Paint.Style.FILL);paint.setColor(0x4e0c192a);c.drawRoundRect(new RectF(0,0,w,h),r,r,paint);
        float fillH=Math.max(dp(10),level*h);
        c.save();c.clipRoundRect(0,0,w,h,r,r);
        paint.setColor(0xffd8e6f6);c.drawRect(0,h-fillH,w,h,paint);
        paint.setColor(0x42ffffff);c.drawRect(0,h-fillH,w,h-fillH+dp(4),paint);
        c.restore();
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(1));paint.setColor(0x9dffffff);
        c.drawRoundRect(new RectF(dp(1),dp(1),w-dp(1),h-dp(1)),r,r,paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setTextSize(dp(30)); paint.setTextAlign(Paint.Align.CENTER);
        paint.setColor(level>0.23?0xff26364b:0xfff4f8ff);
        c.drawText(symbol,w/2,h-dp(25),paint);
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN:dragging=true;getParent().requestDisallowInterceptTouchEvent(true);performClick();
            case MotionEvent.ACTION_MOVE:
                setLevel(1f-e.getY()/Math.max(1,getHeight()));
                if(listener!=null)listener.onChanged(level);return true;
            case MotionEvent.ACTION_UP:case MotionEvent.ACTION_CANCEL:dragging=false;return true;
            default:return false;
        }
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
