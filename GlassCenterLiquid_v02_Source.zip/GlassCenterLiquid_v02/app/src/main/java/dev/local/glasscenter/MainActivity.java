package dev.local.glasscenter;

import android.Manifest;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.view.View;

public final class MainActivity extends Activity {
    private LinearLayout root;
    private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(18));return d;}
    @Override public void onCreate(Bundle b){super.onCreate(b);build();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},31);
    }
    private void txt(String s,int sz,int color){TextView v=new TextView(this);v.setText(s);v.setTextColor(color);v.setTextSize(sz);v.setPadding(0,dp(8),0,dp(8));root.addView(v);}
    private void button(String text,View.OnClickListener action){
        Button b=new Button(this);b.setText(text);b.setAllCaps(false);b.setTextColor(Color.WHITE);
        b.setBackground(shape(0xff2e496a));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(56));lp.topMargin=dp(12);
        root.addView(b,lp);b.setOnClickListener(action);
    }
    private void permissions(String action){
        try{startActivity(new Intent(action,Uri.parse("package:"+getPackageName())));}
        catch(Exception e){startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}
    }
    private void build(){
        ScrollView sc=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20),dp(30),dp(20),dp(32));root.setBackgroundColor(0xff101d30);sc.addView(root);setContentView(sc);
        txt("Glass Center · Liquid Test 0.2",25,Color.WHITE);
        txt("Galaxy S23 / One UI 9 · Android 17",14,0xff9fb8d4);
        txt("Native background blur + animated AGSL glass highlights + vertical sliders + media control. SystemUI stays untouched.",15,0xffd0dfef);
        button("1 · Allow floating window",v->permissions(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
        button("2 · Allow brightness control",v->permissions(Settings.ACTION_MANAGE_WRITE_SETTINGS));
        button("3 · Allow media notification access",v->startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        button("START floating Liquid Control Center",v->{
            if(!Settings.canDrawOverlays(this)){permissions(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);return;}
            try{startForegroundService(new Intent(this,OverlayService.class));}
            catch(Exception e){android.widget.Toast.makeText(this,e.toString(),android.widget.Toast.LENGTH_LONG).show();}
        });
        button("STOP and remove overlay",v->stopService(new Intent(this,OverlayService.class)));
        txt("This version uses Android compositor blur behind the full window. AGSL renders animated glass material but DOES NOT refract real pixels from other apps. Native iOS implementation is proprietary. Real cross-app pixel refraction requires a separate capture/render pipeline or deeper OEM integration.",13,0xffa8bed5);
        txt("No root commands are executed. You can uninstall this test app without altering Samsung SystemUI.",13,0xffa8bed5);
    }
}
